<script setup>
import { ref, computed } from 'vue'
import ItemList from './ItemList.vue'

const items = ref([
  { id: 1, text: 'Piim', isDone: false, importance: 'kõrge' },
  { id: 2, text: 'Leib', isDone: false, importance: 'keskmine' },
  { id: 3, text: 'Kommid', isDone: true, importance: 'madal' }
])
const newItem = ref('')
const newImportance = ref('keskmine')
let nextId = 4

const importanceOrder = { kõrge: 1, keskmine: 2, madal: 3 }
const sortByImportance = list => [...list].sort((a, b) => importanceOrder[a.importance] - importanceOrder[b.importance])
const sortedItems = computed(() => sortByImportance(items.value))
const doneItems = computed(() => sortByImportance(items.value.filter(item => item.isDone)))
const toDoItems = computed(() => sortByImportance(items.value.filter(item => !item.isDone)))

function addItem() {
  const text = newItem.value.trim()
  if (!text) return
  items.value.push({ id: nextId++, text, isDone: false, importance: newImportance.value })
  newItem.value = ''
  newImportance.value = 'keskmine'
}
function deleteItem(id) {
  items.value = items.value.filter(item => item.id !== id)
}
</script>

<template>
  <main class="container">
    <h1>Ostunimekiri</h1>
    <form class="add-form" @submit.prevent="addItem">
      <input v-model="newItem" placeholder="Lisa uus asi..." aria-label="Uus asi" />
      <select v-model="newImportance" aria-label="Olulisus">
        <option value="kõrge">Kõrge</option>
        <option value="keskmine">Keskmine</option>
        <option value="madal">Madal</option>
      </select>
      <button type="submit">Lisa</button>
    </form>
    <div class="lists">
      <ItemList title="All items" :items="sortedItems" @delete-item="deleteItem" />
      <ItemList title="ToDo items" :items="toDoItems" @delete-item="deleteItem" />
      <ItemList title="Done items" :items="doneItems" @delete-item="deleteItem" />
    </div>
  </main>
</template>

<style>
body { background: #f5f5f5; margin: 0; }
.container { max-width: 1100px; margin: 30px auto; padding: 20px; font-family: Arial, sans-serif; }
h1 { text-align: center; }
.add-form { display: flex; gap: 10px; margin-bottom: 25px; }
.add-form input { flex: 1; min-width: 0; padding: 10px; }
.add-form select, .add-form button { padding: 10px; }
.add-form button { cursor: pointer; }
.lists { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 20px; }
@media (max-width: 750px) { .lists { grid-template-columns: 1fr; } }
</style>
