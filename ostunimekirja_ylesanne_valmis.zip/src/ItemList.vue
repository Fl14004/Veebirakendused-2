<script setup>
defineProps({
  title: { type: String, required: true },
  items: { type: Array, required: true }
})
const emit = defineEmits(['delete-item'])
</script>

<template>
  <section class="item-list">
    <h2>{{ title }}</h2>
    <p v-if="items.length === 0">Nimekiri on tühi.</p>
    <ul v-else>
      <li v-for="item in items" :key="item.id"
          :class="['item', 'importance-' + item.importance, { completed: item.isDone }]">
        <label>
          <input v-model="item.isDone" type="checkbox" />
          <span>{{ item.text }}</span>
        </label>
        <span class="importance-label">{{ item.importance }}</span>
        <button type="button" @click="emit('delete-item', item.id)">Kustuta</button>
      </li>
    </ul>
  </section>
</template>

<style scoped>
.item-list { background: white; padding: 15px; border: 1px solid #ddd; border-radius: 6px; }
h2 { font-size: 20px; }
ul { padding: 0; list-style: none; }
.item { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; margin-bottom: 8px; padding: 10px; border-radius: 4px; }
.item label { display: flex; align-items: center; gap: 8px; flex: 1; min-width: 100px; }
.importance-kõrge { background: #ffcaca; }
.importance-keskmine { background: #fff0ad; }
.importance-madal { background: #c9f2cd; }
.importance-label { font-size: 12px; text-transform: capitalize; }
.completed label span { text-decoration: line-through; }
button { cursor: pointer; }
</style>
