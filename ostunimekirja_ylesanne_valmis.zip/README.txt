Ostunimekirja ülesanne – olulisus, sorteerimine ja värvid

1. Ava olemasolev ta25blearnfront Vue projekt.
2. Kopeeri selle ZIP-faili src/App.vue ja src/ItemList.vue oma projekti src kausta.
3. Asenda vanad samanimelised failid.
4. Käivita projekt tavapäraselt (nt bun run dev või npm run dev).

Lahendus sisaldab kolme olulisuse taset, näidisandmeid, computed-sorteerimist kõigis kolmes nimekirjas, värve, lisamist, kustutamist ja tehtuks märkimist.

See ZIP sisaldab asendatavaid Vue komponente, mitte kogu Vue projekti.
